<img src="main_header.png" width="850">
# BluetoothTap Demo
The BluetoothTap library is a simple SDK that enables you to work with Sensor Labs Tap beacons.
## Requirements
Android Studio 2.0
Support minSdkVersion 18
## Installation
To use the BluetoothTap library, you need to include the BluetoothTap aar file into your library folder.
Then add the ability to scan your library folder into the outer gradle file

```
allprojects {
    repositories {
        flatDir {
            dirs 'libs'
        }
    }
}
```

Then in your app gradle configuration provide the name of the aar file

```
dependencies {
    ....
    //tapping library
    compile(name: 'bluetoothtap-2.0.0', ext: 'aar')
}
```
## Usage
There are two required permissions BLUETOOTH_ADMIN and BLUETOOTH in order to start using the library.
Bluetooth must be enabled to use the library.

You will need to start the `BluetoothTapBeaconService` to start searching for beacons.
`this` refers to the target activity and the second parameter determines if you want to show logs or not.

```java
BluetoothTapBeaconService mBluetoothTapBeaconService = BluetoothTapBeaconService.getInstance(this,true);
mBluetoothTapBeaconService.start()
```

And to stop it you just call stop()

```java
mBluetoothTapBeaconService.stop()
```

When you want to focus on one beacon and apply different algorithms for scanning it you will be using `BluetoothTapDetector`.
`this` refers to the target activity and the second parameter determines if you want to show logs or not. Setting second parameter to true allows you to see logs.
```java
mBluetoothTapDetector mBluetoothTapDetector = new BluetoothTapDetector(this, true);
mBluetoothTapDetector.setTouchInListener(this);
mBluetoothTapDetector.setBeaconDetailsListener(this);
mBluetoothTapDetector.setAlgorithm(Algorithm.MAGNETIC_THRESHOLD);
// mBeacon will be the beacon you are scanning
mBluetoothTapDetector.setBeacon(mBeacon);
```

After this, you can implement one or both of the following listeners depending on the detail of information you need from the library and initialize the detector in the listening Activity.

1. Simple listener : you need to implement `TouchInListener` and override the following methods
```java
void touchInRegistered(); // Called when a touch in is successful
void touchInNotRegistered(); // Called when touch in is unsuccessful
void updateTouchInProgress(int progress); // State of touch in progress
```
2. Detail listener : you need to implement `BeaconDetailsListener` and override the following methods
```java
void magnitudeChanged(double reading);
void ambientChanged(double reading); // updating ambient value for MAGNETO algorithm
void thresholdChanged(double threshold); // updating TH value for MAGNETO
void magneticFieldChanged(double filteredMagnitude); // HIGH PASS FILTER updates
void rateChanged(double rate); // updating MAGNETIC THRESHOLD algorithm
void beaconDiscovered(Beacon beacon, boolean aboveThreshold);// event from BluetoothTapBeaconService
```

## License
Copyright 2016 Sensor Labs Ltd

UK Patent Application Number 1509628.2
