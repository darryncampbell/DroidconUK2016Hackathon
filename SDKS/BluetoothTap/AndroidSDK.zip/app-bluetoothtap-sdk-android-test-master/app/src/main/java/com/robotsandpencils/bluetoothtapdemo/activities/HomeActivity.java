package com.robotsandpencils.bluetoothtapdemo.activities;

import com.robotsandpencils.bluetoothtap.BluetoothTapBeaconService;
import com.robotsandpencils.bluetoothtap.models.Beacon;
import com.robotsandpencils.bluetoothtapdemo.App;
import com.robotsandpencils.bluetoothtapdemo.Helpers;
import com.robotsandpencils.bluetoothtapdemo.R;
import com.robotsandpencils.bluetoothtapdemo.dialogs.EnableBluetoothDialog;
import com.squareup.otto.Bus;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.inject.Inject;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by RobotsAndPencils on 15-12-21.
 */
public class HomeActivity extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback, EnableBluetoothDialog.Listener, BluetoothTapBeaconService.BeaconServiceListener {


    @Inject
    Bus mBus;

    @Bind(R.id.progress_label)
    TextView mProgressLabel;

    @Bind(R.id.progress_layout)
    LinearLayout mProgressLayout;

    @Bind(R.id.container)
    RelativeLayout mRootLayout;

    private Handler mHandler;

    private BluetoothTapBeaconService mBeaconService;

    private static final int LIST_UPDATE_INTERVAL = 1000;

    private static final int REQUEST_LOCATION = 0;

    private static final int REQUEST_ENABLE_BT = 1;

    private ListView mBeaconList;

    private List<Beacon> mBeacons;

    private BeaconAdapter mBeaconAdapter;

    private Map<String, Long> mBeaconUpdateTimes;

    private Snackbar mBluetoothSnackbar;

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                        BluetoothAdapter.ERROR);
                switch (state) {
                    case BluetoothAdapter.STATE_OFF:

                        mBeaconService.stop();
                        mProgressLayout.setVisibility(View.INVISIBLE);

                        mBeacons.clear();
                        mBeaconAdapter.notifyDataSetChanged();

                        showBluetoothSnackbar();

                        break;

                    case BluetoothAdapter.STATE_ON:

                        mProgressLayout.setVisibility(View.INVISIBLE);

                        if (mBluetoothSnackbar != null && mBluetoothSnackbar.isShown()) {
                            mBluetoothSnackbar.dismiss();
                        }

                        checkLocationPermission();
                        break;
                }
            }
        }
    };

    private Runnable mUpdateListRunnable = new Runnable() {
        @Override
        public void run() {
            mBeaconAdapter.notifyDataSetChanged();
            mHandler.postDelayed(this, LIST_UPDATE_INTERVAL);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        ((App) getApplication()).getAppComponent().inject(this);

        setContentView(R.layout.activity_home);

        ButterKnife.bind(this);

        mBeaconService = BluetoothTapBeaconService.getInstance(this, true);

        mBeacons = new ArrayList<>();
        mBeaconUpdateTimes = new HashMap<>();

        mHandler = new Handler();

        mBeaconList = (ListView) findViewById(R.id.beacon_list);
        mBeaconList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(HomeActivity.this, BeaconActivity.class);
                intent.putExtra("BEACON", mBeacons.get(position));
                startActivity(intent);
            }
        });

        mBeaconAdapter = new BeaconAdapter(this, R.layout.beacon_list_item, mBeacons);
        mBeaconList.setAdapter(mBeaconAdapter);

        // Register for broadcasts on BluetoothAdapter state change
        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(mReceiver, filter);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowHomeEnabled(true);
            actionBar.setIcon(R.drawable.ic_logo_actionbar);
        }

        checkBluetoothEnabled();
    }


    @Override
    public void beaconDiscovered(Beacon beacon) {

        ListIterator<Beacon> iterator = mBeacons.listIterator();
        int counter = 0;
        while(iterator.hasNext()){
            Beacon tmpBeacon = iterator.next();
            if(tmpBeacon.getMacAddress().equals(beacon.getMacAddress())){
                mBeacons.remove(counter);
            }
            counter++;
        }

        // save beacon update timestamp in hashmap
        mBeaconUpdateTimes.put(beacon.getMacAddress(), System.currentTimeMillis());

        mBeacons.add(beacon);

        mBeaconAdapter.notifyDataSetChanged();

        if (mBeacons.size() > 0) {
            mProgressLayout.setVisibility(View.INVISIBLE);
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        mBus.register(this);

        mBeaconService.setListener(this);

        mHandler.postDelayed(mUpdateListRunnable, LIST_UPDATE_INTERVAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mBus.unregister(this);

        mHandler.removeCallbacks(mUpdateListRunnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mBeaconService != null && isFinishing()) {
            mBeaconService.stop();
        }

        unregisterReceiver(mReceiver);
    }

    private void checkLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestLocationPermission();
        } else {
            startBeaconService();
        }
    }

    private void requestLocationPermission() {

        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.ACCESS_FINE_LOCATION)) {

            Snackbar.make(mRootLayout, R.string.location_permission_required,
                    Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.ok, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            ActivityCompat.requestPermissions(HomeActivity.this,
                                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                    REQUEST_LOCATION);
                        }
                    })
                    .show();
        } else {

            Snackbar.make(mRootLayout, R.string.location_permission_required_2,
                    Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.ok, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            ActivityCompat.requestPermissions(HomeActivity.this,
                                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                    REQUEST_LOCATION);
                        }
                    })
                    .show();
        }
    }

    /**
     * Callback received when a permissions request has been completed.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        if (requestCode == REQUEST_LOCATION) {

            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Snackbar.make(mRootLayout, R.string.location_permission_granted,
                        Snackbar.LENGTH_SHORT).show();

                startBeaconService();
            } else {
                requestLocationPermission();
            }
        }
    }

    private void checkBluetoothEnabled() {
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter != null && !mBluetoothAdapter.isEnabled()) {
            showBluetoothSnackbar();
        } else {
            checkLocationPermission();
        }
    }

    private void showBluetoothSnackbar() {

        mBluetoothSnackbar = Snackbar.make(mRootLayout, R.string.bluetooth_required, Snackbar.LENGTH_INDEFINITE)
                .setAction(R.string.ok, new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        EnableBluetoothDialog enableBluetoothDialog = new EnableBluetoothDialog();
                        enableBluetoothDialog.show(fragmentManager, EnableBluetoothDialog.TAG);
                    }
                });

        mBluetoothSnackbar.show();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

    }

    private void startBeaconService() {
        mProgressLabel.setText(R.string.looking_for_beacons);
        mProgressLayout.setVisibility(View.VISIBLE);
        mBeaconService.start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ENABLE_BT) {

            Helpers.unlockCurrentOrientation(this);

            if (resultCode == RESULT_OK) {
                checkLocationPermission();
            } else {
                showBluetoothSnackbar();
            }
        }
    }

    @Override
    public void onEnableBluetoothDialogConfirm() {
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter != null && !mBluetoothAdapter.isEnabled()) {

            mProgressLabel.setText(R.string.enabling_bluetooth);
            mProgressLayout.setVisibility(View.VISIBLE);

            mBluetoothAdapter.enable();
        }
    }

    @Override
    public void onEnableBluetoothDialogCancel() {
        showBluetoothSnackbar();
    }


    class BeaconAdapter extends ArrayAdapter<Beacon> {

        Context mContext;

        int layoutResourceId;

        List<Beacon> beacons;

        public BeaconAdapter(Context context, int layoutResourceId, List<Beacon> beacons) {
            super(context, layoutResourceId, beacons);

            this.layoutResourceId = layoutResourceId;
            this.mContext = context;
            this.beacons = beacons;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder;
            if (convertView != null) {
                holder = (ViewHolder) convertView.getTag();
            } else {
                LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
                convertView = inflater.inflate(layoutResourceId, parent, false);
                holder = new ViewHolder(convertView);
                convertView.setTag(holder);
            }

            Beacon beacon = beacons.get(position);

            holder.minor.setText(String.format(getResources().getString(R.string.minor), beacon.getMinor()));
            holder.major.setText(String.format(getResources().getString(R.string.major), beacon.getMajor()));
            holder.rssi.setText(String.format(getResources().getString(R.string.rssi_status), beacon.getRssi()));

            long timeDiff = (System.currentTimeMillis() - mBeaconUpdateTimes.get(beacon.getMacAddress())) / 1000;
            holder.timestamp.setText(String.format(getResources().getString(R.string.timestamp), timeDiff));

            return convertView;
        }

        class ViewHolder {

            @Bind(R.id.minor)
            TextView minor;

            @Bind(R.id.major)
            TextView major;

            @Bind(R.id.rssi)
            TextView rssi;

            @Bind(R.id.proximity)
            TextView proximity;

            @Bind(R.id.timestamp)
            TextView timestamp;

            public ViewHolder(View view) {
                ButterKnife.bind(this, view);
            }
        }
    }


}
