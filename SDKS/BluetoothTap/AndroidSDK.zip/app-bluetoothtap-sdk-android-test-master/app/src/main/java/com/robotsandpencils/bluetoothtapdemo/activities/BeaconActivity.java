package com.robotsandpencils.bluetoothtapdemo.activities;

import com.robotsandpencils.bluetoothtap.BluetoothTapDetector;
import com.robotsandpencils.bluetoothtap.models.Beacon;
import com.robotsandpencils.bluetoothtap.utils.Algorithm;
import com.robotsandpencils.bluetoothtapdemo.App;
import com.robotsandpencils.bluetoothtapdemo.R;
import com.squareup.otto.Bus;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.ViewFlipper;

import javax.inject.Inject;

import butterknife.Bind;
import butterknife.ButterKnife;

/**
 * Created by RobotsAndPencils on 4/6/16.
 */
public class BeaconActivity extends AppCompatActivity implements BluetoothTapDetector.TouchInListener, BluetoothTapDetector.BeaconDetailsListener {

    private static final int DEMO_STATE_WAIT = 0;

    private static final int DEMO_STATE_OUT = 1;

    private static final int DEMO_STATE_IN = 2;

    private static final int DEMO_STATE_BT_OFF = 3;

    @Inject
    Bus mBus;

    @Bind(R.id.progress)
    ProgressBar mProgressBar;

    @Bind(R.id.demo_mode_flipper)
    ViewFlipper mDemoModeFlipper;

    private Beacon mBeacon;

    private BluetoothTapDetector mBluetoothTapDetector;

    private long mMagneticTapRegisteredTimestamp = Long.MAX_VALUE;

    /**
     * At least one RSSI reading was received from beacon
     */
    private boolean mIsBeaconConnected;

    /**
     * Time scope for the charts
     */

    private boolean mMagneticTapRegistered = false;

    private MediaPlayer mMediaPlayer;

    private BluetoothAdapter mBluetoothAdapter;

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
                        BluetoothAdapter.ERROR);
                switch (state) {
                    case BluetoothAdapter.STATE_OFF:
                        mIsBeaconConnected = false;
                        switchToBToffState();
                        break;
                    case BluetoothAdapter.STATE_ON:
                        switchToWaitState();
                        break;
                }
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ((App) getApplication()).getAppComponent().inject(this);

        setContentView(R.layout.activity_beacon);

        ButterKnife.bind(this);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // Register for broadcasts on BluetoothAdapter state change
        IntentFilter filter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(mReceiver, filter);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowHomeEnabled(true);
            actionBar.setIcon(R.drawable.ic_logo_actionbar);
        }

        Bundle bundle = getIntent().getExtras();
        mBeacon = bundle.getParcelable("BEACON");
        setTitle("Beacon - " + (mBeacon == null ? "" : mBeacon.getMacAddress()));

        initMagneticTapDetector();

    }


    @Override
    protected void onResume() {
        super.onResume();

        mBus.register(this);

        mMediaPlayer = MediaPlayer.create(this, R.raw.tap_sound);

        // every time the app going to foreground switch to WAIT state
        switchToWaitState();

        reloadSettings();
    }

    private void updateProgress(int progress) {

        mProgressBar.setProgress(progress);

    }

    private void switchToWaitState() {
        mIsBeaconConnected = false;

        updateDemoMode(DEMO_STATE_WAIT);
        updateProgress(BluetoothTapDetector.PROGRESS_STATE_WAIT);
    }

    private void switchToBToffState() {
        updateDemoMode(DEMO_STATE_BT_OFF);
        updateProgress(BluetoothTapDetector.PROGRESS_STATE_BT_OFF);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mBus.unregister(this);

        mMediaPlayer.release();
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (mBluetoothTapDetector != null) {
            mBluetoothTapDetector.onStart();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (mBluetoothTapDetector != null) {
            // stop beacon tap detector, but do not stop beacon service
            // it's still required in MainActivity
            mBluetoothTapDetector.onStop(false);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mBluetoothTapDetector != null) {
            mBluetoothTapDetector.onDestroy();
        }

        unregisterReceiver(mReceiver);
    }

    private void reloadSettings() {
        mDemoModeFlipper.setVisibility(View.VISIBLE);
    }

    private void initMagneticTapDetector() {

        mBluetoothTapDetector = new BluetoothTapDetector(this,true);
        mBluetoothTapDetector.setTouchInListener(this);
        mBluetoothTapDetector.setBeaconDetailsListener(this);
        mBluetoothTapDetector.setAlgorithm(Algorithm.MAGNETIC_THRESHOLD);
        if (mBeacon != null) {
            mBluetoothTapDetector.setBeacon(mBeacon);
        }

    }

    /**
     * @param value               Magnitude value being checked
     * @param th                  Threshold value
     * @param deactivateWithDelay If true the flag label will turn to "OUT" after a delay
     */
    private void updateTapState(double value, int th, boolean deactivateWithDelay) {

        if (!mBluetoothAdapter.isEnabled() || !mIsBeaconConnected) {
            return;
        }

        if (value > th && !mMagneticTapRegistered) {
            mMagneticTapRegisteredTimestamp = System.currentTimeMillis();
            mMagneticTapRegistered = true;

        } else if (value < th && mMagneticTapRegistered && (!deactivateWithDelay || System.currentTimeMillis() - mMagneticTapRegisteredTimestamp > 1000)) {

            mMagneticTapRegisteredTimestamp = Long.MAX_VALUE;
            mMagneticTapRegistered = false;
            updateDemoMode(DEMO_STATE_OUT);
        }
    }

    /**
     * BeaconatorTapDetector interface implementation
     */
    @Override
    public void touchInRegistered() {

        vibrate();
        playSound();

        updateDemoMode(DEMO_STATE_IN);
    }

    /**
     * BeaconatorTapDetector interface implementation
     */
    @Override
    public void touchInNotRegistered() {
        updateDemoMode(DEMO_STATE_OUT);
    }

    @Override
    public void updateTouchInProgress(int progress) {
        updateProgress(progress);
    }

    private void updateDemoMode(int state) {

        mDemoModeFlipper.setDisplayedChild(state);
    }


    private void vibrate() {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(100);
    }

    private void playSound() {
        mMediaPlayer.start();
    }

    @Override
    public void magnitudeChanged(double v) {

    }

    @Override
    public void ambientChanged(double v) {

    }

    @Override
    public void thresholdChanged(double v) {

    }

    @Override
    public void magneticFieldChanged(double v) {

    }

    @Override
    public void rateChanged(double rate) {
        updateTapState(rate, mBluetoothTapDetector.getRateChangeThreshold(), true);
    }

    @Override
    public void beaconDiscovered(Beacon beacon, boolean aboveThreshold) {
        if (!mBeacon.getMacAddress().equals(beacon.getMacAddress())) {
            // signal from wrong beacon received
            return;
        }

        if (!mIsBeaconConnected) {
            // we just received first update from beacon
            // switch state from WAIT to OUT
            updateDemoMode(DEMO_STATE_OUT);
        }

        mIsBeaconConnected = true;

        if (!aboveThreshold) {
            updateDemoMode(DEMO_STATE_OUT);
        }

    }
}
