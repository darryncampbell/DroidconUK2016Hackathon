package com.robotsandpencils.bluetoothtapdemo.modules;

import com.robotsandpencils.bluetoothtapdemo.App;
import com.squareup.otto.Bus;
import com.squareup.otto.ThreadEnforcer;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by RobotsAndPencils on 15-12-21.
 */

@Module
public class AppModule {

    App mApplication;

    public AppModule(App application) {
        mApplication = application;
    }

    @Provides
    @Singleton
    App providesApplication() {
        return mApplication;
    }

    @Provides
    @Singleton
    Context provideApplicationContext() {
        return mApplication;
    }

    @Provides
    @Singleton
    Bus provideBus() {
        return new AndroidBus();
    }

    class AndroidBus extends Bus {

        private final Handler mainHandler = new Handler(Looper.getMainLooper());

        public AndroidBus() {
            super(ThreadEnforcer.ANY);
        }

        @Override
        public void post(final Object event) {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                super.post(event);
            } else {
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        post(event);
                    }
                });
            }
        }
    }

}
