package com.robotsandpencils.bluetoothtapdemo.dialogs;

import com.robotsandpencils.bluetoothtapdemo.R;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;


/**
 * Created by RobotsAndPencils on 15-05-20.
 */
public class EnableBluetoothDialog extends DialogFragment {

    public final static String TAG = "CONFIRMATION_DIALOG";

    private boolean mCancelled = true;

    public interface Listener {
        void onEnableBluetoothDialogConfirm();
        void onEnableBluetoothDialogCancel();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (!(activity instanceof Listener)) {
            throw new ClassCastException(activity.toString() + " must implement Listener");
        }
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (mCancelled) {
            ((Listener) getActivity()).onEnableBluetoothDialogCancel();
        }
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        Dialog dialog = new AlertDialog.Builder(getActivity())
                .setMessage(R.string.enable_bluetooth_message)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mCancelled = false;
                        ((Listener) getActivity()).onEnableBluetoothDialogConfirm();
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mCancelled = true;
                        ((Listener) getActivity()).onEnableBluetoothDialogCancel();
                    }
                })
                .create();

        dialog.setCanceledOnTouchOutside(false);

        return dialog;
    }
}
