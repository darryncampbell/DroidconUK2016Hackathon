package com.robotsandpencils.bluetoothtapdemo;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.view.Surface;
import android.view.WindowManager;

import java.util.List;

/**
 * Created by RobotsAndPencils on 15-12-21.
 */
public class Helpers {
    public static String toCamelCase(String str) {
        if (str.length() > 1) {
            return str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
        } else {
            return str;
        }
    }

    public static void unlockCurrentOrientation(Activity activity) {
        activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

}
