package com.robotsandpencils.bluetoothtapdemo.modules;

import com.robotsandpencils.bluetoothtapdemo.activities.BeaconActivity;
import com.robotsandpencils.bluetoothtapdemo.activities.HomeActivity;

import javax.inject.Singleton;

import dagger.Component;

/**
 * Component generally used for network related injection.
 * Created by RobotsAndPencils on 15-12-21.
 */
@Singleton
@Component(modules = {AppModule.class})
public interface AppComponent {

    void inject(HomeActivity activity);
    void inject(BeaconActivity activity);

}
