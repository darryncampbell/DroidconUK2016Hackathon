package com.robotsandpencils.bluetoothtapdemo;

import com.robotsandpencils.bluetoothtapdemo.modules.AppComponent;
import com.robotsandpencils.bluetoothtapdemo.modules.AppModule;
import com.robotsandpencils.bluetoothtapdemo.modules.DaggerAppComponent;

import android.app.Application;

/**
 * Created by RobotsAndPencils on 15-12-18.
 */
public class App extends Application {

    public final static String TAG = "BluetoothTap Demo";

    private AppComponent mAppComponent;

    @Override
    public void onCreate() {
        super.onCreate();

        if (mAppComponent == null) {
            AppComponent appComponent = DaggerAppComponent.builder()
                    .appModule(new AppModule(this))
                    .build();

            mAppComponent = appComponent;
        }
    }

    public AppComponent getAppComponent() {
        return mAppComponent;
    }

}
